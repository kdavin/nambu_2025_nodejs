console.log("Hello World");
console.log('Hello World');
console.log(`Hello ${"world"}`);

console.log(`52 + 45 = ${52 + 45}`);
console.log("Hello \n World");
console.log("Hello\tWorld");

console.log(23);
console.log(23 + 45);